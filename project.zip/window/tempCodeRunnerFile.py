
        scroll.setFrameShape(QFrame.NoFrame)